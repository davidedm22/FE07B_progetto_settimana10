import { Component, OnInit } from '@angular/core';
import { Todo } from '../models/todo';
import * as service from '../todos.service';

@Component({
  template: `
  <div>
      <ng-container  *ngIf="todos; else elseTemplate">
        <div *ngIf="todos.length > 0; else elseNoTask">
          <div *ngFor="let task of todos; let i = index">
            <div>- {{ task.title }}</div>
          </div>
        </div>
      </ng-container>
      <ng-template #elseTemplate>
        <p>Recupero i task...</p>
      </ng-template>
    </div>
    <ng-template #elseNoTask> <p>Non ci sono task completati, qui 📝</p> </ng-template>
  `,
//  <!-- <ng-container *ngIf="todos; else elseTemplate">
  //     <div class="centrato">
  //       <ul>
  //         <li *ngFor="let item of todos; let i = index">
  //           <p>Ops... non ci sono task</p>
  //         </li>
  //       </ul>
  //     </div>
  //   </ng-container>

  //   <ng-template #elseTemplate>
  //     <p class="center">Recupero task completati...</p>
  //   </ng-template> -->


  styles: [

  ],
})
export class CompletedPage {
  todos!: Todo[];
  constructor() {
    this.getTodo();

  }
  getTodo() {
    service.get().then((todos) => {
      this.todos = todos.filter((todo) => todo.completed);
      console.log(todos);
    });
  }
}

