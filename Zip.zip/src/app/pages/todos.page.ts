import { Component, OnInit } from '@angular/core';
import { Todo } from '../models/todo';
import * as service from '../todos.service';

@Component({
  template: `
  <ng-container *ngIf="todos; else elseTemplate">
    <div *ngIf="todos.length > 0; else elseNoTask" class="center">
      <div>
        <ul>
          <li *ngFor="let item of todos; let i = index">
            {{ item.title }}<button (click)="setFalse(item, i)">✅</button>
          </li>
        </ul>
      </div>
    </div>
  </ng-container>
  <div class="centrato">
    <input type="text" [(ngModel)]="todo" />
    <button (click)="aggiungi()"> + </button>
  </div>

  <ng-template #elseTemplate>
    <p class="center">Recupero Task...</p>
  </ng-template>
  <ng-template #elseNoTask>
    <p class="center">Oops, non ci sono Task</p>
  </ng-template>
`,
styles: [
  `
    .centrato {
      width: auto;
      heigth: auto;
      margin: 50px auto;
    }
  `,
],
})
export class TodosPage {
todo!:string;
todos!: Todo[];
i!: number;

constructor() {
  this.getTodo();
}

getTodo() {
  service.get().then((todos) => {
    this.todos = todos.filter((todo) => !todo.completed);
  });
}

aggiungi() {
  service.add(this.todo).then((todos) => {
    console.log(todos);
    this.todo = '';
    this.getTodo()
  });

}
setFalse(todos: Todo, i: number) {
  service.setTodoAsComplete(todos, i).then(()=>this.getTodo());
  this.getTodo();
}
}






// export class TodosPage  {
//   i!:number;
//   todo = ""
//   todos!: Todo[];
//   constructor() {
//     TodoServizio.get().then((todos) =>{
//       this.todos = todos;
//     });
//   }
//    aggiungi(){
//      TodoServizio.add(this.todo).then((todos) =>{
//        console.log(todos);
//        this.todo = ""
//      });
//    }
// }
